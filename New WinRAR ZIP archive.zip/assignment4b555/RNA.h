#ifndef RNA_H
#define RNA_H
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Sequence.h"
#include "Protein.h"
#include "CodonsTable.h"
using namespace std;
//enum RNA_Type {mRNA, pre_mRNA, mRNA_exon, mRNA_intron};
class RNA : public Sequence
{
private:
    RNA_Type type;
    class Protein;
public:
    char * seq;
    char* tem;
    // constructors and destructor
    RNA(); ///empty constructor
    RNA(const char * seq,int length, RNA_Type atype); ///parameterize constructor
    RNA(RNA& rhs); ///copy constructor
    ~RNA();
    friend istream& operator >> (istream& in, RNA& rna)
{
    cout << " Enter your RNA sequence :" << endl ;
    for ( int i =0 ; i <rna.length ; i++)
    {
        in >> rna.seq[i];
    }
    for ( int i=0 ; i<rna.length ; i++)
    {
        rna.tem[i]=rna.tem[i];
    }
}
    // function to be overridden to print all the RNA information
    void Print();
    // function to convert the RNA sequence into protein sequence
    // using the codonsTable object
    void ConvertToProtein(const CodonsTable & table);
    // function to convert the RNA sequence back to DNA
    void ConvertToDNA();
};

#endif // RNA_H
