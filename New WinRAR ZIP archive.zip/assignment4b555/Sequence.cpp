#include "Sequence.h"
#include <iostream>
using namespace std;
Sequence::Sequence()
{
    //ctor
}///default constructor
Sequence :: Sequence(int l) ///parameterize ctor for l
    {
        cout << "Enter your length :";
        while (l%3!=0 || l <= 0)
        {
            cout << "Renter your length :" ;
            cin >> l;
        }
        length = l;
    }
Sequence :: Sequence (char*seq , int l){
     cout << "Enter your length :";
        while (l%3!=0 || l <= 0)
        {
            cout << "Renter your length :" ;
            cin >> l;
        }
        length = l;
        this -> seq =new char [l];
        for (int i=0 ; i< l ; i++){
            this -> seq[i]=seq[i];
        }
}
Sequence :: Sequence(const Sequence& rhs) ///copy constructor
    {
        this->seq = new char[rhs.length];
        this->length=rhs.length;
        for(int i = 0; i < length; ++i){
           seq[i] = rhs.seq[i];
    }
    }
 Sequence::  ~Sequence()
    {
        delete [] this ->seq;
    }
    // pure virtual function that should be overridden because every
    // type of sequence has its own details to be printed
    void Sequence::Print(){
    cout << this -> seq ;
    cout << endl;
    }
    // friend function that will find the LCS (longest common
    // subsequence) between 2 sequences of any type, according to
    // polymorphism
    char* Sequence::Align(Sequence * s1){}
