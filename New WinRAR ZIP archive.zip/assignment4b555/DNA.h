#ifndef DNA_H
#define DNA_H
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Sequence.h"
#include "RNA.h"
using namespace std;

class DNA : public Sequence
{
public:
    char * seq;
    char* temp;
    // constructors and destructor
    DNA();
    void sett(DNA_Type t);
    DNA(const char * seq,int lenght, DNA_Type atype );  ///parametrize constructor
    DNA(const DNA& rhs); ///copy constructor
    ~DNA();
    friend istream& operator >> (istream& in, DNA& dna)
{
    cout << " Enter your DNA type :" ;
    int num ;
    cout << " Enter 0 for Exit, 1 for promoter, 2 for  motif, 3 for tail,and 4 for noncoding \(^-^)/" <<endl;
    cin >> num;
    switch (num)
    {
    case 0:
        break;
    case 1:
        dna.sett(promoter);
        break;
    case 2:
        dna.sett(motif);
        break;
    case 3:
        dna.sett(tail);
        break;
    case 4:
        dna.sett(noncoding);
        break;
    }
    cout << " Enter your main strand of DNA :" ;
    for (int i=0 ; i < dna.length ; i++)
    {
        return in >> dna.seq[i];
    }
    for ( int i=0 ; i<dna.length ; i++)
    {
        dna.temp[i]=dna.seq[i];
    }
}
    // function printing DNA sequence information to user
    void Print();
    // function to convert the DNA sequence to RNA sequence
    // It starts by building the complementary_strand of the current
    // DNA sequence (starting from the startIndex to the endIndex), then,
    // it builds the RNA corresponding to that complementary_strand.
    void ConvertToRNA();
    // function to build the second strand/pair of DNA sequence
    // To build a complementary_strand (starting from the startIndex to
    // the endIndex), convert each A to T, each T to A, each C to G, and
    // each G to C. Then reverse the resulting sequence.
    void BuildComplementaryStrand();

private:
    DNA_Type type;
    char* complementary_strand;
    int startIndex;
    int endIndex;
    DNA_Type temp1;
};

#endif // DNA_H
