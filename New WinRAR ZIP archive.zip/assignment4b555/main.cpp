#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Sequence.h"
#include "DNA.h"
#include "RNA.h"
#include "CodonsTable.h"
#include "Protein.h"
using namespace std ;
DNA_Type d1, d2, d3, d4 ;
int main()
{
    return 0;
}

