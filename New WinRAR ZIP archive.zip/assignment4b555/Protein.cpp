#include "Protein.h"
#include "RNA.h"
using namespace std ;
Protein::Protein()
{
    //ctor
}
Protein :: Protein (const char * seq , int length , Protein_Type atype){
    this -> length = length;
    this -> seq = new char [length];
    for(int i = 0; i < length; ++i){
        this->seq[i] = seq[i];
    }
    this->type = atype;
}
Protein :: Protein (const Protein & rhs){
    this -> seq = new char [rhs.length];
    this -> length = length;
    for(int i = 0; i < this->length; ++i){
        this->seq[i] = rhs.seq[i];}
          this->type = rhs.type;
}
Protein::~Protein(){
    }
    // return an array of DNA sequences that can possibly
    // generate that protein sequence
    void Protein:: GetDNAStrandsEncodingMe(const DNA & bigDNA){}
