#ifndef SEQUENCE_H
#define SEQUENCE_H
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
using namespace std;
enum DNA_Type {promoter, motif, tail, noncoding};
enum RNA_Type {mRNA, pre_mRNA, mRNA_exon, mRNA_intron};
class Sequence
{
public:
    int length;
    class DNA ;
    class RNA ;
    class Protein ;
    DNA_Type d1, d2, d3, d4 ;
     // constructors and destructor
    Sequence(); ///empty constructor
    Sequence(int l);
    Sequence (char*seq , int l);
    Sequence(const Sequence& rhs); ///copy constructor
    friend operator >> (istream& in, Sequence& l){
        cout << " Enter your sequence type :";
        int type;
        cout << "Enter 1 if you want DNA , 2 if you want RNA , 3 if you want protein :";
        cin >> type ;
        switch (type)
        {
        case 1:
            DNA ob(char*seq, DNA_Type type);
            break;
        case 2:
            RNA ob(char * seq, RNA_Type atype);
            break;
        case 3:
            Protein ob(char * p);
            break;
        }
    }
    virtual ~Sequence();
    // pure virtual function that should be overridden because every
    // type of sequence has its own details to be printed
    virtual void Print();
    // friend function that will find the LCS (longest common
    // subsequence) between 2 sequences of any type, according to
    // polymorphism
    char* Align(Sequence * s1);
protected:
    char * seq;
};

#endif // SEQUENCE_H
