#include "RNA.h"
#include "DNA.h"
using namespace std;
RNA::RNA()
{
    //ctor
}
RNA :: RNA(const char * seq,int length, RNA_Type atype) ///parameterize constructor
    {
         cout << "Enter your length :";
        while (length%3!=0 || length <= 0)
        {
            cout << "Renter your length :" ;
            cin >> length;
        }
        this->length = length;
        this -> seq =new char [length];
        for (int i=0 ; i< length; i++){
            this -> seq[i]=seq[i];
        }
        type = atype;
        for(int i = 0; i < length; ++i){
          if(seq[i] != 'A' && seq[i] != 'C' && seq[i] != 'G' && seq[i] != 'U')
            cout << "please enter only ACGU";
    }
    }
   RNA:: RNA(RNA& rhs) ///copy constructor
    {
        this->seq =new char [rhs.length];
        this -> length = rhs.length;
        for(int i = 0; i < length; ++i){
           this->seq[i] = rhs.seq[i];
    }
    }
   RNA:: ~RNA()
    {
        delete [] this-> seq;
    }
    // function to be overridden to print all the RNA information
    void RNA :: Print(){}
    // function to convert the RNA sequence into protein sequence
    // using the codonsTable object
    void RNA :: ConvertToProtein(const CodonsTable & table)
    {
        char * protein = new char [length/3];
        int x =0 ;
        for (int i=0 ; i< length ; i+=3){
            for (int j=0 ; j < 64 ; j++){
                if (this -> seq[i] == table.codons[j].value[0]&& this->seq[i+1] == table.codons[j].value[1] && this->seq[i+2] == table.codons[j].value[2]){
                        if(table.codons[j].AminoAcid == 'X') break;
                        protein[x++] = table.codons[j].AminoAcid;
                        break;
            }
        }
    }
    for ( int i=0 ; i<length/3 ; i++)
        cout << protein[i];
    delete [] protein;
    }
    // function to convert the RNA sequence back to DNA
    void RNA :: ConvertToDNA()
    {
        int x,x1;
        cout << "Enter 1 for your start and end , and Enter -1 if you want all strand :" ;
        int num ;
        cin >> num ;
        switch(num)
        {
        case 1:
            cout << "Enter your start and end :";
            cin >>x >>x1 ;
            tem = new char [x1-x];
            cout << " your RNA strand is :" << endl;
            for ( int i=x; i <= x1; i++)
            {
                cout << tem[i]<<" " ;
            }
            cout << endl;
            cout << " your DNA strand is :" << endl;
            for ( int i=x; i <= x1 ; i++ )
            {
                if ( tem[i] == 'U')
                {
                    tem[i] = 'T';
                    cout <<tem[i] << " " ;
                }
                else
                    cout << tem[i] << " ";
            }
            cout << endl;
            delete [] tem;
            break;
        case -1:
            tem = new char [length];
            cout << " your RNA strand is :" << endl;
            for ( int i=0 ; i <= length ; i++)
            {
                cout << tem[i]<<" " ;
            }
            cout << endl;
            cout << " your DNA strand is :" << endl;
            for ( int i=0 ; i < length ; i++)
            {
                if ( tem[i] == 'U')
                {
                    tem[i] = 'T';
                    cout <<tem[i] << " ";
                }
                else
                    cout << tem[i] << " ";

            }
            cout << endl;
        }
        delete []tem;
    }
