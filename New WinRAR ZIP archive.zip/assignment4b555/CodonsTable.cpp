#include "CodonsTable.h"
using namespace std;
CodonsTable::CodonsTable()
{
    //ctor
}
CodonsTable::~CodonsTable()
{
    //dtor
}
    // function to load all codons from the given text file
    void CodonsTable::LoadCodonsFromFile()
    {
        ifstream file;
        file.open("r.txt");
        if (file.fail())
        {
            cout << "Input file opening failed" << endl;
            exit(1);
        }
        else
        {
            string t;
            char c;
            int x = 0;
            while (file >> t && file >> c)
            {
                codons[x].AminoAcid = c;
                codons[x].value[0] = t[0];
                codons[x].value[1] = t[1];
                codons[x].value[2] = t[2];
                ++x;
            }
        }
    }
    ///
    char CodonsTable::getAminoAcid(char * value){///const char*value
        for (int i=0 ; i < 64 ; i++){
            if (codons[i].value[i] == value[i])
            return codons[i].AminoAcid;
        }
    }
    void CodonsTable :: setCodon( char * value, char AminoAcid, int index){
        this->codons[index].value[index] = value[index];
        this->codons[index].AminoAcid = AminoAcid;
    }
