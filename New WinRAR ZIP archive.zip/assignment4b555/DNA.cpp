#include "DNA.h"
#include "RNA.h"
using namespace std;
DNA::DNA()
{
    //ctor
}
void DNA :: sett(DNA_Type t)
    {
        temp1  =t;
    }
 DNA::DNA(const char * seq, int length , DNA_Type atype )  ///parametrize constructor
    {
        cout << "Enter your length :";
        while (length%3!=0 || length <= 0)
        {
            cout << "Renter your length :" ;
            cin >> length;
        }
        this->length = length;
        this -> seq =new char [length];
        for (int i=0 ; i< length ; i++){
            this -> seq[i]=seq[i];
        }
        this->seq = new char [length];
        for(int i = 0; i < length; ++i){
          this->seq[i] = seq[i];
    }
        type = atype;
         for(int i = 0; i < length; ++i){
                if(seq[i] != 'A' && seq[i] != 'C' && seq[i] != 'G' && seq[i] != 'T')
                        cout <<"please enter only ACGT...\n";
    }
    }
   DNA::DNA(const DNA& rhs) ///copy constructor
    {
        this -> seq = new char [rhs.length];
        this -> length = rhs.length;
        for(int i = 0; i < this->length; ++i){
        this->seq[i] = rhs.seq[i];
    }
        this->type = rhs.type;
    }
    DNA::~DNA()
    {
        delete[] this->seq;
    }
    // function printing DNA sequence information to user
    void DNA:: Print()
    {
        cout << " Your DNA type : " << endl;
        if (temp1 == 0)
            cout << "your type is promoter" << endl;
        else if (temp1 == 1)
            cout << "your type is motif" << endl;
        else if (temp1 == 2)
            cout << "your type is tail" << endl;
        else if (temp1 == 3)
            cout << "your type is noncoding" << endl;
        else
        {
        }
       DNA:: BuildComplementaryStrand();
    }
    // function to convert the DNA sequence to RNA sequence
    // It starts by building the complementary_strand of the current
    // DNA sequence (starting from the startIndex to the endIndex), then,
    // it builds the RNA corresponding to that complementary_strand.
    void DNA:: ConvertToRNA()
    {
        temp=new char[this->length];
        cout << "Enter 1 for your start and end , and Enter -1 if you want all strand :" ;
        int num ;
        cin >> num ;
        switch(num)
        {
        case 1:
            cout << "Enter your start and end :";
            cin >> startIndex >> endIndex ;
            cout << " your DNA strand is :" << endl;
            for ( int i=startIndex ; i <= endIndex ; i++)
            {
                cout << temp[i]<<" " ;
            }
            cout << endl;
            cout << " your RNA strand is :" << endl;
            for ( int i=startIndex ; i <= endIndex ; i++ )
            {
                if ( temp[i] == 'T')
                {
                    temp[i] = 'U';
                    cout <<temp[i] << " " ;
                }
                else
                    cout << temp[i] << " ";
            }
            cout << endl;
            delete [] temp;
            break;
        case -1:
            cout << " your DNA strand is :" << endl;
            for ( int i=0 ; i <= length ; i++)
            {
                cout << temp[i]<<" " ;
            }
            cout << endl;
            cout << " your RNA strand is :" << endl;
            for ( int i=0 ; i < length ; i++)
            {
                if ( temp[i] == 'T')
                {
                    temp[i] = 'U';
                    cout <<temp[i] << " ";
                }
                else
                    cout << temp[i] << " ";
            }
            cout << endl;
        }
        delete[] temp;
    }
    // function to build the second strand/pair of DNA sequence
    // To build a complementary_strand (starting from the startIndex to
    // the endIndex), convert each A to T, each T to A, each C to G, and
    // each G to C. Then reverse the resulting sequence.
    void DNA ::BuildComplementaryStrand()
    {
        cout << "Enter 1 for your start and end , and Enter -1 if you want all strand :" ;
        int num ;
        cin >> num ;
        switch(num)
        {
        case 1:
            cout << "Enter your start and end :";
            cin >> startIndex >> endIndex ;
            complementary_strand = new char [endIndex-startIndex];
            cout << " your strand is :" << endl;
            for ( int i=startIndex ; i <= endIndex ; i++)
            {
                cout << this -> seq << " " ;
            }
            cout << endl;
            cout << " your complimentary strand is :" << endl;
            for ( int i=startIndex ; i <= endIndex ; i++ )
            {
                if ( this -> seq[i] == 'A')
                    complementary_strand[i] = 'T';
                else if ( this -> seq[i] == 'T')
                    complementary_strand[i] ='A';
                else if ( this -> seq[i] == 'C')
                    complementary_strand[i] = 'G';
                else if ( this -> seq[i] == 'G')
                    complementary_strand[i] ='C';
                else
                    cout <<"Error,Please enter only ACGT";
                cout << complementary_strand[i]<< " " ;
            }
            cout << endl;
            break;
        case -1:
            cout << " your strand is :" << endl;
            for ( int i=0 ; i < length ; i++)
            {
                cout << this -> seq [i] << " ";
            }
            cout << endl;
            cout << " your complimentary strand is :" << endl;
            for ( int i=0 ; i < length ; i++)
            {
                if ( this-> seq[i] == 'A')
                    complementary_strand[i] = 'T';
                else if ( this-> seq[i]  == 'T')
                    complementary_strand[i] ='A';
                else if ( this-> seq[i]  == 'C')
                    complementary_strand[i] = 'G';
                else if ( this-> seq[i]  == 'G')
                    complementary_strand[i] ='C';
                cout << complementary_strand[i] << " " ;
            }
        }
        cout << endl;
    }
